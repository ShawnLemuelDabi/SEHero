<!doctype html>
<html lang="en">
<?php
include "header.php";
?>

<body>
<?php
include "navbar.php";
?>



</body>
</html>