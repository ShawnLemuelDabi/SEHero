<!-- Navigation -->
<nav class="navbar navbar-light bg-light fixed-top">
    <div class="container">
        <a class="navbar-brand" href="howToUseMe.php">How to use me</a>
        <a class="navbar-brand" href="index.php#year1">Year 1</a>
        <a class="navbar-brand" href="index.php#year2">Year 2</a>
    </div>
</nav>